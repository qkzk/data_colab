/*=================================================================
	File created by Yohann NICOLAS.

  Changing the current save path.

=================================================================*/
#pragma once

#include "common.h"

extern char* savePath;
extern bool active_changingSavePath;

void Install_ChangingSavePath();

/*================================= END OF FILE =================================*/
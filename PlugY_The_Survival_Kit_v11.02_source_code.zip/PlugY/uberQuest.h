/*=================================================================
	File created by Yohann NICOLAS.

	Uber Quest Management.

=================================================================*/
#pragma once

#include "common.h"

extern bool active_UberQuest;

void Install_UberQuest();
void resetQuestState();

/*================================= END OF FILE =================================*/
/*=================================================================
	File created by Yohann NICOLAS.

	Interface Stats functions

=================================================================*/
#pragma once

#include "common.h"

void Install_InterfaceStats();

/*================================= END OF FILE =================================*/

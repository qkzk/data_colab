/*=================================================================
	File created by Yohann NICOLAS.

	Set global variable.

=================================================================*/
#pragma once

#include "common.h"

extern bool onRealm;
extern bool needToInit;

void Install_VariableOnRealm();

/*================================= END OF FILE =================================*/
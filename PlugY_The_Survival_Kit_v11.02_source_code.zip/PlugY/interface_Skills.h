/*=================================================================
	File created by Yohann NICOLAS.

	Interface Skills functions

=================================================================*/
#pragma once

#include "common.h"

void Install_InterfaceSkills();

/*================================= END OF FILE =================================*/
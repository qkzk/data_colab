/*=================================================================
	File created by Yohann NICOLAS.

	New Stat Interface

=================================================================*/
#pragma once

#include "common.h"

void STDCALL printNewStatsPage();
DWORD STDCALL mouseNewStatsPageLeftDown(sWinMessage* msg);
DWORD STDCALL mouseNewStatsPageLeftUp(sWinMessage* msg);

/*================================= END OF FILE =================================*/

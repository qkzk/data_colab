/*=================================================================
	File created by Yohann NICOLAS.

	Change Skill win per level up.

=================================================================*/
#pragma once

#include "common.h"

extern bool active_SkillPerLevelUpChange;
extern DWORD skillPerLevelUp;

void Install_SkillPerLevelUp();

/*================================= END OF FILE =================================*/
/*=================================================================
	File created by Yohann NICOLAS.

	Updating Client.

=================================================================*/
#pragma once

#include "common.h"

void Install_UpdateClient();
void updateClient(Unit* ptChar, DWORD mFunc, DWORD p1, DWORD p2, DWORD p3);
void updateClient(Unit* ptChar, DWORD mFunc, char* msg);

/*================================= END OF FILE =================================*/
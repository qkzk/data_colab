/*=================================================================
	File created by Yohann NICOLAS.

	Others features.

=================================================================*/
#pragma once

#include "common.h"

extern bool active_othersFeatures;

void Install_OthersFeatures();
void Install_ChangeResolution();

/*================================= END OF FILE =================================*/
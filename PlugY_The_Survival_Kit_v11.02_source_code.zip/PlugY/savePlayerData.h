/*=================================================================
	File created by Yohann NICOLAS.

  Save Player Custom Data.

=================================================================*/
#pragma once

#include "common.h"

void Install_SavePlayerData();

/*================================= END OF FILE =================================*/
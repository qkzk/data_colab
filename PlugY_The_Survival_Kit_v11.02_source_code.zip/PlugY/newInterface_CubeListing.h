/*=================================================================
	File created by Yohann NICOLAS.

	Cube Listing functions

=================================================================*/
#pragma once

#include "common.h"

void listAllCubeFormula();

/*================================= END OF FILE =================================*/

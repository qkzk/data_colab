/*=================================================================
	File created by Yohann NICOLAS.

	Use a more big stash

=================================================================*/
#pragma once

#include "common.h"

extern bool active_bigStash;
extern bool active_bigStash_tested;

void Install_BigStash();

/*================================= END OF FILE =================================*/
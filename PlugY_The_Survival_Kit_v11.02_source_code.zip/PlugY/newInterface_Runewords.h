/*=================================================================
	File created by Yohann NICOLAS.

	New runeword Interface

=================================================================*/
#pragma once

#include "common.h"

void STDCALL printRunewordsPage();
DWORD STDCALL mouseRunewordsPageLeftDown(sWinMessage* msg);
DWORD STDCALL mouseRunewordsPageLeftUp(sWinMessage* msg);

/*================================= END OF FILE =================================*/

/*=================================================================
	File created by Yohann NICOLAS.

  Load Player Custom Data.

=================================================================*/
#pragma once

#include "common.h"

void Install_LoadPlayerData();

/*================================= END OF FILE =================================*/

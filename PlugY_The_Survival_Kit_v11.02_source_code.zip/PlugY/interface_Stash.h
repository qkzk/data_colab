/*=================================================================
	File created by Yohann NICOLAS.

	Interface functions

=================================================================*/
#pragma once

#include "common.h"

void Install_InterfaceStash();

/*================================= END OF FILE =================================*/
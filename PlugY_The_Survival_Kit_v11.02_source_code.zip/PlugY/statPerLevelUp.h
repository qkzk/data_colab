/*=================================================================
	File created by Yohann NICOLAS.

	Change Stat win per level up.

=================================================================*/
#pragma once

#include "common.h"

extern bool active_StatPerLevelUpChange;
extern DWORD statPerLevelUp;

void Install_StatPerLevelUp();

/*================================= END OF FILE =================================*/
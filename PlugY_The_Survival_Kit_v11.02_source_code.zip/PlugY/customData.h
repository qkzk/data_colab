/*=================================================================
	File created by Yohann NICOLAS.

  Data added to D2 base-stucture

=================================================================*/
#pragma once

#include "playerCustomData.h"

#define CBPlayerData void
#define CBItemData void

/*================================= END OF FILE =================================*/
/*=================================================================
	File created by Yohann NICOLAS.

  Add an extra save file for each characters.

=================================================================*/
#pragma once
/*
#include "common.h"

DWORD loadClientSaveFile();
DWORD saveClientSaveFile();
*/
/*================================= END OF FILE =================================*/
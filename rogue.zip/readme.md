# installer cet environnement virtuel

1. décompresser et coller le dossier si possible à la racine sinon où vous pouvez
2. Editer les fichiers :

*	pyenv.cfg : remplacez l'adresse par celle de votre exécutable python3
*	activate.ps1 : même chose mais pour la variable $env, vers l'adresse du dossier \rogue\venv\
* 	Script/activate.bat : remplacez 
	set "VIRTUAL_ENV=C:\Users\quentin\Desktop\rogue\venv"
	par l'adresse de locale de votre dossier \venv
* 	activate : meme chose, ligne 40


et ça devrait être bon.

# Utiliser

Vous exécutez le script activate.bat depuis la console

```
c:\...\rogue>venv\activate
```

Vous serez alors dans alors un environnement virtuel, on le remarque parce que (venv) est écrit devant votre nom

Testez le :

```
c:\...\rogue>python
...
...
>>> import tcod
>>>
```

L'importation doit se dérouler sans problème et ne pas afficher d'erreur.

Vous pouvez suivre le tutoriel sans problème.

Remarquez qu'il faut toujours être dans l'environnement pour que l'importation de la librairie se déroule bien.
# **Exercice 3 : Modification et automatisation**

Dans cet exercice on manipule l'arborescence crée à l'exercice précédent. 

## Question 1 : Modification de l’arborescence  

1. Supprimez le fichier `app.log`.  
2. Supprimez le répertoire `data/` et tout son contenu.  
3. Déplacez le répertoire `tests/` dans le répertoire `src/`.  

Donnez les commandes Linux utilisées pour chacune des étapes.  

---

## Question 2 : Script Python et test  

**1. Écriture d’un script Python élémentaire**  

- Créez un fichier nommé `plus_ou_moins.py` dans le répertoire `src/`. 
- Ouvrez le avec l'éditeur de texte `nano` : `nano plus_ou_moins.py` depuis son dossier.
- Le contenu du script est le suivant :  

```python
#!/usr/bin/python

import random

def jeu_plus_ou_moins():
    print("Bienvenue au jeu du Plus ou Moins !")
    nombre_mystere = random.randint(1, 100)
    essai = None

    while essai != nombre_mystere:
        essai = int(input("Devinez un nombre entre 1 et 100 : "))
        if essai < nombre_mystere:
            print("C'est plus !")
        elif essai > nombre_mystere:
            print("C'est moins !")
        else:
            print("Bravo ! Vous avez trouvé.")

jeu_plus_ou_moins()
```

- Pour l'enregistrer faites Ctrl+x et validez. Vérifiez le contenu avec `cat`.

**2. Rendre le script exécutable**  

- Rendez le fichier `plus_ou_moins.py` exécutable avec : `chmod +x plus_ou_moins.py`
- Testez son exécution en le lançant directement avec : `./plus_ou_moins.py`  

**Consignes :**  

- Expliquez les commandes utilisées pour rendre le script exécutable.  


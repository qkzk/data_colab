#!/bin/bash

# Création de l'arborescence
mkdir -p racine/dossier1 racine/dossier2/sous_dossier racine/dossier3

# Création des fichiers
echo "Ceci est le fichier 1" > racine/dossier1/fichier1.txt
echo "Ceci est le fichier 2" > racine/dossier1/fichier2.txt
echo "Bravo, vous avez trouvé le fichier caché !" > racine/dossier1/.cache.txt
echo "Ceci est le fichier 3" > racine/dossier2/fichier3.txt
echo "Ceci est le fichier 4" > racine/dossier2/sous_dossier/fichier4.txt
echo "Ceci est le fichier 5" > racine/dossier3/fichier5.txt

echo "Arborescence créée avec succès."


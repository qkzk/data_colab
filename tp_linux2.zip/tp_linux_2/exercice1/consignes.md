# Exploration de l’arborescence

## Consignes :

### Créer l'arborescence utilisée

Dans le dossier courant se trouve un script _bash_ appelé `script_exo1.sh`.

Exécutez le avec `./script_exo1.sh`

Une arborescence est créée pour la suite de l'exercice.

### Explorer l'arborescence

Depuis le répertoire racine, trouvez le fichier caché nommé .cache.txt en utilisant des commandes Linux appropriées.

Pour valider votre réponse :

Indiquez les commandes utilisées pour naviguer dans les répertoires et afficher leur contenu.
Montrez le texte trouvé dans le fichier .cache.txt.

### Rappels :

- Utilisez `ls -a` pour voir les fichiers cachés.
- Déplacez-vous avec `cd` pour explorer les répertoires.
- Affichez le contenu d’un fichier avec cat

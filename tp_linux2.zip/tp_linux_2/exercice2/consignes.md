# **Exercice 2 : Création et navigation dans une arborescence**

## Question 1 : Création d’une arborescence  

Créez une arborescence de fichiers sur le bureau qui respecte le modèle suivant :  

```
projet/
├── src/
│   ├── main.py
│   ├── utils.py
│   └── README.md
├── tests/
│   ├── test_main.py
│   ├── test_utils.py
├── data/
│   ├── input.txt
│   ├── output.txt
└── logs/
    └── app.log
```

**Consignes :**  
- Créez cette structure à la main en utilisant uniquement des commandes Linux (`mkdir`, `touch`, etc.).  
- Assurez-vous que chaque fichier existe et contient un contenu minimal. Par exemple :  
  - `README.md` contient : `Documentation du projet`.
  - `app.log` contient : `Logs d'exécution`.
  - Les autres fichiers contiennent simplement une phrase descriptive.

---

## Question 2 : Adresses absolues et relatives  

1. L’adresse **absolue** et **relative** du fichier `test_main.py` par rapport au :  
   - Répertoire `projet/`.  
   - Répertoire `tests/`.  

2. L’adresse **absolue** et **relative** du fichier `output.txt` par rapport au :  
   - Répertoire `data/`.  
   - Répertoire `src/`.  

**Rappel :**
- Une adresse **absolue** commence à partir de `/` (la racine du système).  
- Une adresse **relative** est donnée par rapport à un répertoire de référence.


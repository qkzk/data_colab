#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
source : http://effbot.org/imagingbook/introduction.htm


0 Comment utiliser ce tutoriel ?

Chaque manipulation est commentée sur plusieurs lignes avec les "triple simple quote = trois apostrophes = ''' ''' "
Pour chaque manip, enlever les trois apostrophes avant et après. 
Lancer le script dans Python (run module dans IDLE, python tuto_image.py dans la commande). 
Certaines manip agissent directement sur un fichier, il vaut mieux alors la lancer depuis la console (windows : python tuto_image ou exec)
C'est toujours précisé dans la manipulation.



I bases

1.1. fonctions de base
1.2. ecriture & lecture
1.3. copier, coller, joindre
1.4. transformations geometriques
1.5. changement de type de couleur (RGB -> L)


II Amélioration de l'image

2.1 filtres
2.2. contraste
2.3 utilisation de ImageEnhance
2.4 mélange de deux images avec blend
'''


#I bases
#1.1. fonctions de base
'''

from PIL import Image #charge la librairie image
im = Image.open("tiger.jpg") #chargement d'une image dans une variable
print im.format, im.size, im.mode #affichage des infos de l'image : taille couple (531, 411) mode : (L : nx gris, RGB vraies couleurs, CMYK pre print)
im.show() #affiche l'image. peut planter s'il detecte pas le lecteur d'image
#remarque sur .show() : sauvegarde l'image en BMP dans un fichier temporaire et l'ouvre avec le lecteur xv ou celui du systeme si detecte
'''

#1.2. ecritude & lecture

#convertir en jpg, a charger avec le nom de l'image a convertir 
'''
import os, sys #chargement des librairies propres au systeme d'exploitation et de manipulation des fichiers
from PIL import Image #charge la libririe image

for infile in sys.argv[1:]: #pour le fichier en argument,
    f, e = os.path.splitext(infile) #f contiendra le nom du fichier et e son adresse
    outfile = f + ".jpg" #nom du fichier de sortie en jpg
    if infile != outfile: #si le nom du fichier de sortie pas le meme que celui du fichier d'entree
        try: #essaye 
            Image.open(infile).save(outfile) #ouvre l'image, converti et sauvegarde en jpg
        except IOError: #si t'as une erreur IO : le fichier n'est pas convertible
            print "cannot convert", infile #affiche qu'on peut pas convertir
'''
#creer des miniatures, !!! a charger avec le nom de l'image a convertir !!!
'''
import os, sys
from PIL import Image

size = 128, 128 												#taille de la miniature

for infile in sys.argv[1:]: 									#f contiendra le nom du fichier et e son adresse
    outfile = os.path.splitext(infile)[0] + ".thumbnail.jpg" 	#type de fichier de sortie : thumbnail
    if infile != outfile: 										#si les noms sont pas les meme
        try:
            im = Image.open(infile) 							#ouvre l'image
            im.thumbnail(size) 									#cree le thumbnail
            im.save(outfile, "JPEG") 							#sauvegarde
        except IOError:
            print "cannot create thumbnail for", infile

'''

#affiche les informations d'un fichier !!! a charger avec le nom de l'image a convertir !!!
#lire le les infos d'un fichier est tres rapide, on ne charge pas l'image
#ne fonctionne que depuis la fenetre de commande, inaccessible au lycée donc.
'''
import sys
from PIL import Image

for infile in sys.argv[1:]:
    try:
        im = Image.open(infile)
        print infile, im.format, "%dx%d" % im.size, im.mode   #affiche les infos de l'image
    except IOError:
        pass
'''
#1.3. couper, coller, joindre
'''
#crop
from PIL import Image 						#charge la librairie image
im = Image.open("tiger.jpg") 				#chargement d'une image dans une variable
print im.format, im.size, im.mode 			#affichage des infos de l'image : taille couple (531, 411) mode : (L : nx gris, RGB vraies couleurs, CMYK pre print)
im.show() 									#affiche l'image. peut planter s'il detecte pas le lecteur d'image
box = (100, 100, 400, 400) 					#coordonnees de la boite
region = im.crop(box) 						#decoupe un cadre entre les 2 pts xA,yA,xB,yB (attention (0,0) en haut a gauche)
region.show() #affiche le crop
'''

#retourne un morceau et ecrase dedans
'''
from PIL import Image 						#charge la librairie image
im = Image.open("tiger.jpg") 				#chargement d'une image dans une variable
print im.format, im.size, im.mode 			#affichage des infos de l'image : taille couple (531, 411) mode : (L : nx gris, RGB vraies couleurs, CMYK pre print)
im.show() 									#affiche l'image. peut planter s'il detecte pas le lecteur d'image
box = (100, 100, 400, 400) 					#coordonnees de la boite
region = im.crop(box) 						#decoupe un cadre entre les 2 pts xA,yA,xB,yB (attention (0,0) en haut a gauche)
region = region.transpose(Image.ROTATE_180)	#1. retourne region
im.paste(region, box) 						#2. colle dans region 
region.show() 								#affiche region : seulement le crop
im.show() 									#affiche ce qu'est devenu im apres le paste

'''
#enrouler une image : décale une partie de l'image et la colle dans une autre partie
'''
from PIL import Image
def roll(image, delta):
    "Roll an image sideways"

    xsize, ysize = image.size

    delta = delta % xsize
    if delta == 0: return image

    part1 = image.crop((0, 0, delta, ysize))
    part2 = image.crop((delta, 0, xsize, ysize))
    image.paste(part2, (0, 0, xsize-delta, ysize))
    image.paste(part1, (xsize-delta, 0, xsize, ysize))
    image.show()

    return image
im = Image.open('tiger.jpg')
im.show()
roll(im,250)
'''


#manipuler couleur par couleur
'''
from PIL import Image
im = Image.open('tiger.jpg')
im.show()
r, g, b = im.split()  					#separe dans r, g et b les 3 niveaux de couleurs
r.show()								#affiche le niveau de rouge dans l'image
b.show()								#affiche le niveau de bleu dans l'image
im = Image.merge("RGB", (b, g, r))		#regroupe les 3 images en echangeant le rouge et le blue
im.show()								#affiche l'horrible resultat
'''


#1.4. transformations geometriques

#resize, rotate
'''
from PIL import Image
im = Image.open('tiger.jpg')
im.show()
out = im.resize((128, 256))		#change les dimensions de l'image sans preserver les proportions
out.show()
out = im.rotate(45) 			# degrees sens direct (inverse des aiguilles d'une montre)
out.show()
'''

#transpositions (symetries axiale et rotations selon les axes)
'''
from PIL import Image
im = Image.open('tiger.jpg')
im.show()
out = im.transpose(Image.FLIP_LEFT_RIGHT)
out.show()
out = im.transpose(Image.FLIP_TOP_BOTTOM)
out.show()
out = im.transpose(Image.ROTATE_90)
out.show()
out = im.transpose(Image.ROTATE_180)
out.show()
out = im.transpose(Image.ROTATE_270)
out.show()

#il existe aussi la methode .transform tres complete (cf http://effbot.org/imagingbook/image.htm#image-transform-method )
'''

#1.5. changement de type de couleur (RGB -> L)

#conversion en niveaux de gris, assez classique.
'''
from PIL import Image
im = Image.open("tiger.jpg").convert("L")   #ouvre l'image, la converti en niveaux de gris
im.show()
'''

'''
The library supports transformations between each supported mode and the “L” and “RGB” modes. 
To convert between other modes, you may have to use an intermediate image (typically an “RGB” image).
'''

#II Amelioration de l'image

#2.1. filtres

#présentation de tous les filtres
'''
from PIL import Image, ImageFilter

im = Image.open('tiger.jpg')

im1 = im.filter(ImageFilter.BLUR)					#floute
im1.show()
im2 = im.filter(ImageFilter.MinFilter(3))			#renvoie le pixel min de chaque pixel, reduit donc la qqt d'info dans le fichier
im2.show()
im3 = im.filter(ImageFilter.MedianFilter(3)) 		#autre façon de faire, avec le pixel median
im3.show()

#d'autres filtres

im4 = im.filter(ImageFilter.CONTOUR)				#ne garde que les contours 
im4.show()
im5 = im.filter(ImageFilter.DETAIL)					#amelioration des détails
im5.show()
im6 = im.filter(ImageFilter.EDGE_ENHANCE)			#amelioration des coins
im6.show()
im7 = im.filter(ImageFilter.SMOOTH)					#adoucit le contour
im7.show()
im8 = im.filter(ImageFilter.SHARPEN)				#affute le contour
im8.show()
'''


#2.2. contraste

'''
#augmenter/diminuer le contraste
from PIL import Image
im = Image.open('tiger.jpg')
im.show()
# augmente le contraste de 20% = multiplier chaque pixel par 1.2
out = im.point(lambda i: i * 1.2)
out.show()
# augmente le contraste de 100% =  doubler chaque pixel
out = im.point(lambda i: i * 2)
out.show()

'''

#traiter chaque bande individuellement
'''
from PIL import Image
im = Image.open('tiger.jpg')
im.show()

# split the image into individual bands
source = im.split()

R, G, B = 0, 1, 2

# select regions where red is less than 100
mask = source[R].point(lambda i: i < 100 and 255)

# process the green band
vert = source[G].point(lambda i: i * 0.7)

# paste the processed band back, but only where red was < 100
source[G].paste(vert, None, mask)

# build a new multiband image
out = Image.merge(im.mode, source)
out.show()
'''

#Relatif à l'exemple précédent
#Creer un masque de fond selon bleu < 100 ou bleu > 100
'''
from PIL import Image
im = Image.open('tiger.jpg')
im.show()
source = im.split()
R, G, B = 0, 1, 2
mask = source[B].point(lambda i: i<100 and 255)  #si lambda i est <100 on aura 0 du noir, sinon on aura 255 du blanc
mask.show()
'''

# 2.3 utilisation de ImageEnhance
# http://effbot.org/imagingbook/imageenhance.htm
#boucle présentant différent niveau de sharpness = piqué
'''
from PIL import Image, ImageEnhance

im = Image.open("migrant_mother.jpg")
sharp = ImageEnhance.Sharpness(im)


for i in range(8):
    factor = i / 4.0
    sharp.enhance(factor).show("Pique %f" % factor)    #0 piqué : très floutée, 1 piqué : image normale, 2 piqué : très découpé
'''


#boucle présentant différent niveaux de brightness = luminosité
'''
from PIL import Image, ImageEnhance

im = Image.open("migrant_mother.jpg")
bright = ImageEnhance.Brightness(im)


for i in range(8):
    factor = i / 4.0
    bright.enhance(factor).show("Brightness %f" % factor)		#augmente la luminosité d'une mage. qd factor vaut 0 noire, 1 vraie, 2 blanche


'''
#boucle présentant différent niveaux de contraste
'''
from PIL import Image, ImageEnhance

im = Image.open("migrant_mother.jpg")
contrast = ImageEnhance.Contrast(im)


for i in range(8):
    factor = i / 4.0
    contrast.enhance(factor).show("Contraste %f" % factor)

'''
#boucle présentant différent niveaux de couleur
'''
from PIL import Image, ImageEnhance

im = Image.open("tiger.jpg")
col = ImageEnhance.Color(im)


for i in range(8):
    factor = i / 4.0
    col.enhance(factor).show("Color %f" % factor)  #manipulation des couleurs, comme sur un vieux téléviseur
'''

#2.4 mélange de deux images avec blend

#boucle présentant comment melanger 2 images avec blend
'''
from PIL import Image
im1 = Image.open('superman.jpg')
im2 = Image.open('batman.jpg')

for i in range(10):
	factor = i / 9.0
	Image.blend(im1,im2,factor).show()	#la 1ere image, la 2eme, la proportion de seconde image à intégrer. 0.4 -> 60% im1, 40% im2
'''

#2.5 virer le gris d'une image N&B
'''
from PIL import Image
im = Image.open("spider.jpg").convert("L")   #ouvre l'image, la converti en niveaux de gris
im.show()

mask1 = im.point(lambda i: i < 125 and 255) #si le niveau est < 125 passe noir
mask2 = im.point(lambda i: i > 125 and 255) #si le niveau est < 125 passe blanc

mask1.show()
mask2.show()
mask2.save('spider_mask.jpg')
'''